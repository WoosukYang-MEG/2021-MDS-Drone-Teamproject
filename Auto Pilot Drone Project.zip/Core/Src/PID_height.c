/*
 * PID_height.c
 *
 *  Created on: 2021. 9. 15.
 *      Author: Creation-23
 */

#include "PID_height.h"

PIDDouble height;

//target_height => gcs hegiht (cm), current_height => LPS22HH.baroAltFilt * 100 (cm)

void Double_Height_Calculation(float target_height, float current_height, PIDDouble* height)
{
/*---------------------------------------------- Single PID ------------------------------------------------------------*/
height->out.reference = target_height; // 목표 고도
height->out.error = target_height - current_height; // 오차 = 목표 고도 - 현재 고도
height->out.p_result = height->out.error * height->out.kp; // p제어 = 오차 * p Gain

height->out.error_sum = height->out.error_sum + height->out.error * 0.001; // 에러 누적 = 에러 + 에러 * 0.001
height->out.i_result = height->out.error_sum * height->out.ki; // i제어 = 에러 누적 * i Gain

height->out.derivative =  current_height - height->out.derivative_prev / 0.001; // 고도 제어 속도 = 현재 고도 - 고도 제어 속도 / 0.001
height->out.derivative_prev = height->out.derivative;  // 이전 고도 제어 속도
height->out.d_result= -(height->out.derivative) * height->out.kd; // d제어 = -(고도 제어 속도) * d Gain

height->out.pid_result = height->out.p_result + height->out.i_result + height->out.d_result; // pid 제어 = p + i + d
/*---------------------------------------------- Double PID ------------------------------------------------------------*/
height->in.reference = height->in.pid_result;
height->in.error = height->in.reference - height->out.derivative;
height->in.p_result = height->in.error * height->in.kp;

height->in.error_sum = height->in.error_sum + height->in.error * 0.001;
height->in.i_result = height->in.error_sum * height->in.ki;

height->in.derivative = (height->out.derivative - height->in.derivative_prev) / 0.001;
height->in.derivative_prev = height->in.derivative;
height->in.d_result = -(height->in.derivative) * height->in.kd;

height->in.pid_result = height->in.p_result + height->in.i_result + height->in.d_result;
}

void Height_Calculation(float target_height, float current_height, PIDDouble* height)
{

}

//ccr -> iBus.LV-1000 -> (throttle_rate_pid);

#ifndef __PID_HEIGHT_H
#define __PID_HEIGHT_H
#ifdef __cplusplus
 extern "C" {
#endif

#include "PID control.h"

extern PIDDouble height;

void Double_Height_Calculation(float target_height, float current_height, PIDDouble* height);


#ifdef __cplusplus
}
#endif
#endif /*__PID_HEIGHT_H */

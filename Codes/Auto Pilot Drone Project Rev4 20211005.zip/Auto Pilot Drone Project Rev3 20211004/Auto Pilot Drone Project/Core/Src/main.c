  /* USER CODE BEGIN Header */
/*
	<TimeLine>
175us : CH2. sensor Interface
10.9us : CH3. GPS data receive
7.5us : CH4. Controller(iBus) data receive
1700us : CH8. FC -> GCS Communication (case transmit 20 bytes, 0x10(ID) AHRS Message)
3400us : CH8. FC -> GCS Communication (case transmit 40 bytes, 0x10(ID) AHRS Message + 0x11(ID) GPS Message)
10us : CH9. Fail-safe
10us : CH11. Roll, Pitch Double PID Control
5us : CH12. Heading Single PID Control
*/
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "BNO080.h"
#include "Quaternion.h"
#include "ICM20602.h"
#include "LPS22HH.h"
#include "M8N.h"
#include "FS-iA6B.h"
#include "AT24C08.h"
#include <string.h>
#include "PID control.h"
#include "PID_height.h"
#include <math.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
int _write(int file, char* p, int len){
	for(int i=0; i<len; i++){
		while(!LL_USART_IsActiveFlag_TXE(USART6));
		LL_USART_TransmitData8(USART6, *(p+i));
	}
	return len;
}
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
typedef struct _DESTGPS{
	signed int lon;
	signed int lat;

	double lon_f63;
	double lat_f63;

	unsigned char gcs_failsafe;
	unsigned short height;
}DESTGPS;
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
extern uint8_t uart6_rx_flag;
extern uint8_t uart6_rx_data;

extern uint8_t m8n_rx_buf[36];
extern uint8_t m8n_rx_cplt_flag;

extern uint8_t ibus_rx_buf[32];
extern uint8_t ibus_rx_cplt_flag;

extern uint8_t uart1_rx_data;

extern uint8_t tim7_20ms_flag;
extern uint8_t tim7_100ms_flag;
extern uint8_t tim7_1000ms_flag;
extern uint8_t tim7_1ms_flag;

extern uint8_t start_cnt;
int start_flag=0;

uint8_t telemetry_tx_buf[40];
uint8_t telemetry_rx_buf[20];
uint8_t telemetry_rx_cplt_flag=0;
float batVolt;

unsigned char failsafe_flag=0;
unsigned char low_bat_flag=0;

unsigned char autopilot_flag=0;
unsigned char arrive_flag=0;
float target_angle;
#define PI 3.14159265358979323
DESTGPS destGPS;

unsigned char time_exceed_flag=1;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
int Is_iBus_Throttle_Min(void);
void ESC_Calibration(void);
int Is_iBus_Received(void);
void BNO080_Calibration(unsigned char autopilot_flag);
void Encode_Msg_AHRS(unsigned char *telemetry_tx_buf);
void Encode_Msg_GPS(unsigned char *telemetry_tx_buf);
void Encode_Msg_PID_Gain(unsigned char *telemetry_tx_buf, unsigned char id, float p, float i, float d);
void receiveGPS_Parsing(unsigned char *telemetry_rx_buf);
float calcAngleGPS(float target_x, float target_y);
void Is_Arrived(void);
void ModeSelectAlram(void);
void AutopilotModeAlram(void);
void ManualpilotModeAlram(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	float q[4];
	float quatRadianAccuracy;
	unsigned short adcVal;

	short gyro_x_offset=58, gyro_y_offset=15, gyro_z_offset=-21;
	unsigned char motor_arming_flag=0;
	unsigned short iBus_SwA_Prev=0;
	unsigned char iBus_rx_cnt=0;

	unsigned short ccr1, ccr2, ccr3, ccr4;

	float yaw_heading_reference;
  /* USER CODE END 1 */
  

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  MX_TIM5_Init();
  MX_TIM7_Init();

  MX_USART1_UART_Init();
  MX_USART6_UART_Init();
  MX_UART4_Init();
  MX_UART5_Init();

  MX_SPI1_Init();
  MX_SPI2_Init();
  MX_SPI3_Init();

  MX_I2C1_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  /* USER CODE BEGIN 2 */
  LL_TIM_EnableCounter(TIM3);

  LL_TIM_EnableCounter(TIM5);		// Motor
  LL_TIM_CC_EnableChannel(TIM5, LL_TIM_CHANNEL_CH1);
  LL_TIM_CC_EnableChannel(TIM5, LL_TIM_CHANNEL_CH2);
  LL_TIM_CC_EnableChannel(TIM5, LL_TIM_CHANNEL_CH3);
  LL_TIM_CC_EnableChannel(TIM5, LL_TIM_CHANNEL_CH4);

  LL_TIM_EnableCounter(TIM7);		// 10Hz, 50Hz 1KHz loop
  LL_TIM_EnableIT_UPDATE(TIM7);


  LL_USART_EnableIT_RXNE(USART6);		// Debug UART
  LL_USART_EnableIT_RXNE(UART4);		// GPS
  LL_USART_EnableIT_RXNE(UART5);		// FS-iA6B
  HAL_UART_Receive_IT(&huart1, &uart1_rx_data, 1);		// Telemetry

  HAL_ADC_Start_DMA(&hadc1, &adcVal, 1);	// Battery ADC

  TIM3->PSC=1000;
  LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
  HAL_Delay(60);
  LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
  HAL_Delay(60);
  LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
  HAL_Delay(60);
  LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
  HAL_Delay(60);
  printf("Checking Sensor Connection.\n");

  if(BNO080_Initialization()!=0){
	  LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);

	  TIM3->PSC=1000;	// 2KHz
	  HAL_Delay(100);
	  TIM3->PSC=1500;	// 3KHz
	  HAL_Delay(100);
	  TIM3->PSC=2000;	// 4KHz
	  HAL_Delay(100);

	  LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);

	  printf("\nBNO080 Failed. Program Shutting down.");

	  while(1){
		  LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
		  LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_0);
		  HAL_Delay(200);
		  LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
		  LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_0);
		  HAL_Delay(200);
	  }
  }
  // below command have to be moved, after select Mode procedure.
  //BNO080_enableRotationVector(2500);		// magnetic field method, absolute value
  //BNO080_enableGameRotationVector(2500);	// Gaming method, relative value


  if(ICM20602_Initialization()!=0){
	  LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);

	  TIM3->PSC=1000;	// 2KHz
	  HAL_Delay(100);
	  TIM3->PSC=1500;	// 3KHz
	  HAL_Delay(100);
	  TIM3->PSC=2000;	// 4KHz
	  HAL_Delay(100);

	  LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);

	  printf("\nICM20602 Failed. Program Shutting down.");

	  while(1){
		  LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
		  LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_1);
		  HAL_Delay(200);
		  LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
		  LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_1);
		  HAL_Delay(200);
	  }
  }
  ICM20602_Writebyte(0x13, (gyro_x_offset*-2)>>8);		// Input ICM20602 Offset Register
  ICM20602_Writebyte(0x14, (gyro_x_offset*-2));
  ICM20602_Writebyte(0x15, (gyro_y_offset*-2)>>8);
  ICM20602_Writebyte(0x16, (gyro_y_offset*-2));
  ICM20602_Writebyte(0x17, (gyro_z_offset*-2)>>8);
  ICM20602_Writebyte(0x18, (gyro_z_offset*-2));

  if(LPS22HH_Initialization()!=0){
	  LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);

	  TIM3->PSC=1000;	// 2KHz
	  HAL_Delay(100);
	  TIM3->PSC=1500;	// 3KHz
	  HAL_Delay(100);
	  TIM3->PSC=2000;	// 4KHz
	  HAL_Delay(100);

	  LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);

	  printf("\nLPS22HH Failed. Program Shutting down.");

	  while(1){
		  LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
		  LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_2);
		  HAL_Delay(200);
		  LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
		  LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_2);
		  HAL_Delay(200);
	  }
  }
  printf("All Sensor OK.\n");

  M8N_Initialization();

  ////////////////////////////////////////////  강제로 고도 게인값을 1로 넣어줌  ////////////////////////////////////////////
  EP_PIDGain_Write(6, 1, 1, 1);
  EP_PIDGain_Read(6, &height.out.kp, &height.out.ki, &height.out.kd);
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  printf("Loading PID Gain.\n");
  if(EP_PIDGain_Read(0, &roll.in.kp, &roll.in.ki, &roll.in.kd)!=0 ||
		  EP_PIDGain_Read(1, &roll.out.kp, &roll.out.ki, &roll.out.kd)!=0 ||
		  EP_PIDGain_Read(2, &pitch.in.kp, &pitch.in.ki, &pitch.in.kd)!=0 ||
		  EP_PIDGain_Read(3, &pitch.out.kp, &pitch.out.ki, &pitch.out.kd)!=0 ||
		  EP_PIDGain_Read(4, &yaw_heading.kp, &yaw_heading.ki, &yaw_heading.kd)!=0 ||
		  EP_PIDGain_Read(5, &yaw_rate.kp, &yaw_rate.ki, &yaw_rate.kd)!=0){
	  LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);

	  TIM3->PSC=1000;	// 2KHz
	  HAL_Delay(100);
	  TIM3->PSC=1500;	// 3KHz
	  HAL_Delay(100);
	  TIM3->PSC=2000;	// 4KHz
	  HAL_Delay(100);

	  LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	  HAL_Delay(500);
	  printf("\nCouldn't load PID Gain.\n");
  }else{
	  Encode_Msg_PID_Gain(telemetry_tx_buf, 0, roll.in.kp, roll.in.ki, roll.in.kd);
	  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);

	  Encode_Msg_PID_Gain(telemetry_tx_buf, 1, roll.out.kp, roll.out.ki, roll.out.kd);
	  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);

	  Encode_Msg_PID_Gain(telemetry_tx_buf, 2, pitch.in.kp, pitch.in.ki, pitch.in.kd);
	  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);

	  Encode_Msg_PID_Gain(telemetry_tx_buf, 3, pitch.out.kp, pitch.out.ki, pitch.out.kd);
	  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);

	  Encode_Msg_PID_Gain(telemetry_tx_buf, 4, yaw_heading.kp, yaw_heading.ki, yaw_heading.kd);
	  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);

	  Encode_Msg_PID_Gain(telemetry_tx_buf, 5, yaw_rate.kp, yaw_rate.ki, yaw_rate.kd);
	  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);

	  printf("\n All Gains OK.\n");
  }


//  ////////////////////////////////////////////////////////
//
//  while(1){
//
//	  if(telemetry_rx_cplt_flag==1){
//		  telemetry_rx_cplt_flag=0;
//
//		  LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
//
//		  TIM3->PSC=1000;	// 2KHz
//		  HAL_Delay(10);
//
//		  LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
//
//		  for(int i=0; i<20; i++){
//			  printf("[%d]Byte : %x\t",i, telemetry_rx_buf[i]);
//		  }
//		  printf("\n\n");
//	  }
//
//	  Encode_Msg_AHRS(telemetry_tx_buf);
//	  Encode_Msg_GPS(telemetry_tx_buf+20);
//
//	  HAL_UART_Transmit_IT(&huart1, telemetry_tx_buf, 40);
//  }
//
//  //////////////////////////////////////////////////////

  // up-code(part), device initailization


  ModeSelectAlram();
  start_flag=1;
  start_cnt=0;

  while(start_cnt <= 10){

	  while(telemetry_rx_cplt_flag != 0){
		  telemetry_rx_cplt_flag=0;

		  unsigned char chksum=0xff;

		  for(int i=0; i<19; i++) chksum-=telemetry_rx_buf[i];

		  if(chksum==telemetry_rx_buf[19]){
			  if(telemetry_rx_buf[2]==0x11){
				  receiveGPS_Parsing(telemetry_rx_buf);
				  time_exceed_flag=0;
				  autopilot_flag=1;
				  break;
			  }
		  }
	  }


	  if(autopilot_flag==1) break;
	  if(Is_iBus_Received()){
		  time_exceed_flag=0;
		  break;
	  }

	  printf("%d\n",start_cnt);
  }
  start_flag=0;
  start_cnt=0;

  if(autopilot_flag==1) BNO080_enableRotationVector(2500);
  else BNO080_enableGameRotationVector(2500);

  if(autopilot_flag==1){
	  AutopilotModeAlram();
	  printf("Auto Mode\n");
  }else{
	  ManualpilotModeAlram();
	  printf("Manual Mode\n");
  }

  if(autopilot_flag!=1){
	 if(time_exceed_flag==1){
		 while(Is_iBus_Received()==0){		// waiting Controller connect
			 LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
			 TIM3->PSC=3000;
			 HAL_Delay(200);
			 LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
			 HAL_Delay(200);		// ringing not connected alram
		 }
	 }

	 if(iBus.SwC==2000){				// controller switch C is low position
		 LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
		 TIM3->PSC=1500;
		 HAL_Delay(200);
		 TIM3->PSC=2000;
		 HAL_Delay(200);
		 TIM3->PSC=1500;
		 HAL_Delay(200);
		 TIM3->PSC=2000;
		 HAL_Delay(200);
		 LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);		// ringing enter esc calibration mode

		 ESC_Calibration();
		 while(iBus.SwC!=1000){		// controller switch is high position: exit loop
			 Is_iBus_Received();		// receive contoller data

			 LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
			 TIM3->PSC=1500;
			 HAL_Delay(200);
			 TIM3->PSC=2000;
			 HAL_Delay(200);
			 LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4); // ringing exit calibration mode
		 }
	 }else if(iBus.SwC==1500){			// controller switch C is middle position
		 LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
		 TIM3->PSC=1500;
		 HAL_Delay(200);
		 TIM3->PSC=2000;
		 HAL_Delay(200);
		 TIM3->PSC=1500;
		 HAL_Delay(200);
		 TIM3->PSC=2000;
		 HAL_Delay(200);
		 LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);		// ringing enter esc calibration mode

		 BNO080_Calibration(autopilot_flag);
		 while(iBus.SwC!=1000){		// controller switch is high position: exit loop
			 Is_iBus_Received();		// receive contoller data

			 LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
			 TIM3->PSC=1500;
			 HAL_Delay(200);
			 TIM3->PSC=2000;
			 HAL_Delay(200);
			 LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4); // ringing exit calibration mode
		 }
	 }

	 while(Is_iBus_Throttle_Min()==0 || iBus.SwA==2000){		// motor safe phase
		 LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
		 TIM3->PSC=1000;
		 HAL_Delay(70);
		 LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
		 HAL_Delay(70);
	 }
  }

  LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);

  TIM3->PSC=2000;	// 2KHz
  HAL_Delay(100);
  TIM3->PSC=1500;	// 3KHz
  HAL_Delay(100);
  TIM3->PSC=1000;	// 4KHz
  HAL_Delay(100);

  LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);

  printf("start \n");		// flush buffer, 200 line

//  int sumCount=0;
//    int sumLPS22HH=0;
//    int baseAvgLPS22HH;
//  start_flag=1;
//  while(start_cnt<3){				//  3초간 기압고도계의 데이터를 얻어와 데이터가 안정화 되기를 기다림, 바로 처음부터 평균값을 구하면 이상해짐
//  	if(LPS22HH_DataReady()==1){
//  			LPS22HH_GetPressure(&LPS22HH.pressure_raw);
//  			LPS22HH_GetTemperature(&LPS22HH.temperature_raw);
//
//  			LPS22HH.baroAlt=getAltitude2(LPS22HH.pressure_raw/4096.f, LPS22HH.temperature_raw/100.f);
//
//  	#define X 0.90f
//  			LPS22HH.baroAltFilt=LPS22HH.baroAltFilt*X+LPS22HH.baroAlt*(1.0f-X);		// well-known digital filter expression
//
//  			//printf("%d %d\n", (int)(LPS22HH.baroAlt*100), (int)(LPS22HH.baroAltFilt*100));		// (X)cm
//
////  			printf("%d\n", (int)(LPS22HH.baroAltFilt*100));
////  			sumCount++;
////  			sumLPS22HH+=LPS22HH.baroAltFilt*100;
//  	}
//  }
//  start_flag=0;
//  start_cnt=0;
//
//  start_flag=1;
//  while(start_cnt<3){				//  안정화됨 데이터를 3초간 얻어와 평균
//    	if(LPS22HH_DataReady()==1){
//    			LPS22HH_GetPressure(&LPS22HH.pressure_raw);
//    			LPS22HH_GetTemperature(&LPS22HH.temperature_raw);
//
//    			LPS22HH.baroAlt=getAltitude2(LPS22HH.pressure_raw/4096.f, LPS22HH.temperature_raw/100.f);
//
//    	#define X 0.90f
//    			LPS22HH.baroAltFilt=LPS22HH.baroAltFilt*X+LPS22HH.baroAlt*(1.0f-X);		// well-known digital filter expression
//
//    			//printf("%d %d\n", (int)(LPS22HH.baroAlt*100), (int)(LPS22HH.baroAltFilt*100));		// (X)cm
//
//    			sumCount++;
//    			sumLPS22HH+=LPS22HH.baroAltFilt*100;
//    	}
//    }
//
//  baseAvgLPS22HH=sumLPS22HH/sumCount;
//  start_flag=0;
//  start_cnt=0;
//
//  while(1){
//	  if(LPS22HH_DataReady()==1){
//	    			LPS22HH_GetPressure(&LPS22HH.pressure_raw);
//	    			LPS22HH_GetTemperature(&LPS22HH.temperature_raw);
//
//	    			LPS22HH.baroAlt=getAltitude2(LPS22HH.pressure_raw/4096.f, LPS22HH.temperature_raw/100.f);
//
//	    	#define X 0.90f
//	    			LPS22HH.baroAltFilt=LPS22HH.baroAltFilt*X+LPS22HH.baroAlt*(1.0f-X);		// well-known digital filter expression
//
//	    			//printf("%d %d\n", (int)(LPS22HH.baroAlt*100), (int)(LPS22HH.baroAltFilt*100));		// (X)cm
//	    			//printf("%d %d %d\n", (int)baseAvgLPS22HH, (int)(LPS22HH.baroAltFilt*100), (int)(LPS22HH.baroAltFilt*100-(int)baseAvgLPS22HH));
//	    			printf("%d\n",(int)(LPS22HH.baroAltFilt*100-(int)baseAvgLPS22HH));
//	    	}
//  }

  if(autopilot_flag==1)
	  goto AutoMode;


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
  while (1)
  {
	  if(tim7_1ms_flag==1){
		  tim7_1ms_flag=0;

		  Double_Roll_Pitch_PID_Calculation(&pitch, (iBus.RV-1500)*0.1f, BNO080_Pitch, ICM20602.gyro_x);
		  Double_Roll_Pitch_PID_Calculation(&roll, (iBus.RH-1500)*0.1f, BNO080_Roll, ICM20602.gyro_y);

		  if(iBus.LV<1030 || motor_arming_flag==0){
			  Reset_All_PID_Integrator();
		  }

		  if(iBus.LH<1485 || iBus.LH>1515){
			  yaw_heading_reference=BNO080_Yaw;
			  Single_Yaw_Rate_PID_Calculation(&yaw_rate, (iBus.LH-1500), ICM20602.gyro_z);

			  ccr1=10500+500+(iBus.LV-1000)*10 - pitch.in.pid_result + roll.in.pid_result - yaw_rate.pid_result;		// range 10500~21000, if out of range unexpected action occur
			  ccr2=10500+500+(iBus.LV-1000)*10 + pitch.in.pid_result + roll.in.pid_result + yaw_rate.pid_result;
			  ccr3=10500+500+(iBus.LV-1000)*10 + pitch.in.pid_result - roll.in.pid_result - yaw_rate.pid_result;
			  ccr4=10500+500+(iBus.LV-1000)*10 - pitch.in.pid_result - roll.in.pid_result + yaw_rate.pid_result;
		  }else{
			  Single_Yaw_Heading_PID_Calculation(&yaw_heading, yaw_heading_reference, BNO080_Yaw, ICM20602.gyro_z);

			  ccr1=10500+500+(iBus.LV-1000)*10 - pitch.in.pid_result + roll.in.pid_result - yaw_heading.pid_result;		// range 10500~21000, if out of range unexpected action occur
			  ccr2=10500+500+(iBus.LV-1000)*10 + pitch.in.pid_result + roll.in.pid_result + yaw_heading.pid_result;
			  ccr3=10500+500+(iBus.LV-1000)*10 + pitch.in.pid_result - roll.in.pid_result - yaw_heading.pid_result;
			  ccr4=10500+500+(iBus.LV-1000)*10 - pitch.in.pid_result - roll.in.pid_result + yaw_heading.pid_result;
		  }
	  }

	  if(iBus.SwA==2000 && iBus_SwA_Prev!=2000){
		  if(iBus.LV<1010){
			  motor_arming_flag=1;
			  yaw_heading_reference=BNO080_Yaw;
		  }else{
			  while(Is_iBus_Throttle_Min()==0 || iBus.SwA==2000){		// motor safe phase
				  LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
				  TIM3->PSC=1000;
				  HAL_Delay(70);
				  LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
				  HAL_Delay(70);
			  }
		  }
	  }
	  iBus_SwA_Prev=iBus.SwA;

	  if(iBus.SwA!=2000){
		  motor_arming_flag=0;
	  }
	  if(motor_arming_flag==1){
		  if(failsafe_flag==0){
			  if(iBus.LV>1030){
				  TIM5->CCR1=(ccr1>21000)?21000:(ccr1<11000)?11000:ccr1;
				  TIM5->CCR2=(ccr2>21000)?21000:(ccr2<11000)?11000:ccr2;
				  TIM5->CCR3=(ccr3>21000)?21000:(ccr3<11000)?11000:ccr3;
				  TIM5->CCR4=(ccr4>21000)?21000:(ccr4<11000)?11000:ccr4;
			  }else{
				  TIM5->CCR1=11000;
				  TIM5->CCR2=11000;
				  TIM5->CCR3=11000;
				  TIM5->CCR4=11000;
			  }
		  }else{
			  TIM5->CCR1=10500;
			  TIM5->CCR2=10500;
			  TIM5->CCR3=10500;
			  TIM5->CCR4=10500;
		  }
	  }else{
		  TIM5->CCR1=10500;
		  TIM5->CCR2=10500;
		  TIM5->CCR3=10500;
		  TIM5->CCR4=10500;
	  }

	  if(telemetry_rx_cplt_flag==1){
		  telemetry_rx_cplt_flag=0;

		  if(iBus.SwA==1000){
			  unsigned char chksum=0xff;

			  for(int i=0; i<19; i++) chksum-=telemetry_rx_buf[i];

			  if(chksum==telemetry_rx_buf[19]){
				  LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);

				  TIM3->PSC=1000;	// 2KHz
				  HAL_Delay(10);

				  LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);

				  switch(telemetry_rx_buf[2]){
				  case 0:
					  roll.in.kp=*(float*)(telemetry_rx_buf+3);
					  roll.in.ki=*(float*)(telemetry_rx_buf+7);
					  roll.in.kd=*(float*)(telemetry_rx_buf+11);
					  EP_PIDGain_Write(telemetry_rx_buf[2], roll.in.kp, roll.in.ki, roll.in.kd);
					  EP_PIDGain_Read(telemetry_rx_buf[2], &roll.in.kp, &roll.in.ki, &roll.in.kd);
					  Encode_Msg_PID_Gain(telemetry_tx_buf, telemetry_rx_buf[2], roll.in.kp, roll.in.ki, roll.in.kd);
					  HAL_UART_Transmit_IT(&huart1, telemetry_tx_buf, 20);
					  break;
				  case 1:
					  roll.out.kp=*(float*)(telemetry_rx_buf+3);
					  roll.out.ki=*(float*)(telemetry_rx_buf+7);
					  roll.out.kd=*(float*)(telemetry_rx_buf+11);
					  EP_PIDGain_Write(telemetry_rx_buf[2], roll.out.kp, roll.out.ki, roll.out.kd);
					  EP_PIDGain_Read(telemetry_rx_buf[2], &roll.out.kp, &roll.out.ki, &roll.out.kd);
					  Encode_Msg_PID_Gain(telemetry_tx_buf, telemetry_rx_buf[2], roll.out.kp, roll.out.ki, roll.out.kd);
					  HAL_UART_Transmit_IT(&huart1, telemetry_tx_buf, 20);
					  break;
				  case 2:
					  pitch.in.kp=*(float*)(telemetry_rx_buf+3);
					  pitch.in.ki=*(float*)(telemetry_rx_buf+7);
					  pitch.in.kd=*(float*)(telemetry_rx_buf+11);
					  EP_PIDGain_Write(telemetry_rx_buf[2], pitch.in.kp, pitch.in.ki, pitch.in.kd);
					  EP_PIDGain_Read(telemetry_rx_buf[2], &pitch.in.kp, &pitch.in.ki, &pitch.in.kd);
					  Encode_Msg_PID_Gain(telemetry_tx_buf, telemetry_rx_buf[2], pitch.in.kp, pitch.in.ki, pitch.in.kd);
					  HAL_UART_Transmit_IT(&huart1, telemetry_tx_buf, 20);
					  break;
				  case 3:
					  pitch.out.kp=*(float*)(telemetry_rx_buf+3);
					  pitch.out.ki=*(float*)(telemetry_rx_buf+7);
					  pitch.out.kd=*(float*)(telemetry_rx_buf+11);
					  EP_PIDGain_Write(telemetry_rx_buf[2], pitch.out.kp, pitch.out.ki, pitch.out.kd);
					  EP_PIDGain_Read(telemetry_rx_buf[2], &pitch.out.kp, &pitch.out.ki, &pitch.out.kd);
					  Encode_Msg_PID_Gain(telemetry_tx_buf, telemetry_rx_buf[2], pitch.out.kp, pitch.out.ki, pitch.out.kd);
					  HAL_UART_Transmit_IT(&huart1, telemetry_tx_buf, 20);
					  break;
				  case 4:
					  yaw_heading.kp=*(float*)(telemetry_rx_buf+3);
					  yaw_heading.ki=*(float*)(telemetry_rx_buf+7);
					  yaw_heading.kd=*(float*)(telemetry_rx_buf+11);
					  EP_PIDGain_Write(telemetry_rx_buf[2], yaw_heading.kp, yaw_heading.ki, yaw_heading.kd);
					  EP_PIDGain_Read(telemetry_rx_buf[2], &yaw_heading.kp, &yaw_heading.ki, &yaw_heading.kd);
					  Encode_Msg_PID_Gain(telemetry_tx_buf, telemetry_rx_buf[2], yaw_heading.kp, yaw_heading.ki, yaw_heading.kd);
					  HAL_UART_Transmit_IT(&huart1, telemetry_tx_buf, 20);
					  break;
				  case 5:
					  yaw_rate.kp=*(float*)(telemetry_rx_buf+3);
					  yaw_rate.ki=*(float*)(telemetry_rx_buf+7);
					  yaw_rate.kd=*(float*)(telemetry_rx_buf+11);
					  EP_PIDGain_Write(telemetry_rx_buf[2], yaw_rate.kp, yaw_rate.ki, yaw_rate.kd);
					  EP_PIDGain_Read(telemetry_rx_buf[2], &yaw_rate.kp, &yaw_rate.ki, &yaw_rate.kd);
					  Encode_Msg_PID_Gain(telemetry_tx_buf, telemetry_rx_buf[2], yaw_rate.kp, yaw_rate.ki, yaw_rate.kd);
					  HAL_UART_Transmit_IT(&huart1, telemetry_tx_buf, 20);
					  break;
				  case 0x10:
					  switch(telemetry_rx_buf[3]){
					  case 0:
						  Encode_Msg_PID_Gain(telemetry_tx_buf, telemetry_rx_buf[3], roll.in.kp, roll.in.ki, roll.in.kd);
						  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);
						  break;
					  case 1:
						  Encode_Msg_PID_Gain(telemetry_tx_buf, telemetry_rx_buf[3], roll.out.kp, roll.out.ki, roll.out.kd);
						  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);
						  break;
					  case 2:
						  Encode_Msg_PID_Gain(telemetry_tx_buf, telemetry_rx_buf[3], pitch.in.kp, pitch.in.ki, pitch.in.kd);
						  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);
						  break;
					  case 3:
						  Encode_Msg_PID_Gain(telemetry_tx_buf, telemetry_rx_buf[3], pitch.out.kp, pitch.out.ki, pitch.out.kd);
						  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);
						  break;
					  case 4:
						  Encode_Msg_PID_Gain(telemetry_tx_buf, telemetry_rx_buf[3], yaw_heading.kp, yaw_heading.ki, yaw_heading.kd);
						  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);
						  break;
					  case 5:
						  Encode_Msg_PID_Gain(telemetry_tx_buf, telemetry_rx_buf[3], yaw_rate.kp, yaw_rate.ki, yaw_rate.kd);
						  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);
						  break;
					  case 6:
						  Encode_Msg_PID_Gain(telemetry_tx_buf, 0, roll.in.kp, roll.in.ki, roll.in.kd);
						  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);
						  Encode_Msg_PID_Gain(telemetry_tx_buf, 1, roll.out.kp, roll.out.ki, roll.out.kd);
						  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);
						  Encode_Msg_PID_Gain(telemetry_tx_buf, 2, pitch.in.kp, pitch.in.ki, pitch.in.kd);
						  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);
						  Encode_Msg_PID_Gain(telemetry_tx_buf, 3, pitch.out.kp, pitch.out.ki, pitch.out.kd);
						  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);
						  Encode_Msg_PID_Gain(telemetry_tx_buf, 4, yaw_heading.kp, yaw_heading.ki, yaw_heading.kd);
						  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);
						  Encode_Msg_PID_Gain(telemetry_tx_buf, 5, yaw_rate.kp, yaw_rate.ki, yaw_rate.kd);
						  HAL_UART_Transmit(&huart1, telemetry_tx_buf, 20, 10);
						  break;
					  }
					  break;
				  }
			  }
		  }
	  }

	  if(tim7_20ms_flag==1 && tim7_100ms_flag!=1){
		  tim7_20ms_flag=0;

		  Encode_Msg_AHRS(telemetry_tx_buf);

		  HAL_UART_Transmit_IT(&huart1, telemetry_tx_buf, 20);
	  }else if(tim7_100ms_flag==1 && tim7_20ms_flag==1){
		  tim7_20ms_flag=0;
		  tim7_100ms_flag=0;

		  Encode_Msg_AHRS(telemetry_tx_buf);
		  Encode_Msg_GPS(telemetry_tx_buf+20);

		  HAL_UART_Transmit_IT(&huart1, telemetry_tx_buf, 40);
	  }

	  batVolt=adcVal*0.003619f;
	  //	  printf("%d\t%.2f\n", adcVal, batVolt);
	  if(batVolt<10.0f){
		  low_bat_flag=1;
	  }else{
		  low_bat_flag=0;
	  }

	  if(BNO080_dataAvailable()==1){
		  LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_0);

		  q[0]=BNO080_getQuatI();
		  q[1]=BNO080_getQuatJ();
		  q[2]=BNO080_getQuatK();
		  q[3]=BNO080_getQuatReal();
		  quatRadianAccuracy=BNO080_getQuatRadianAccuracy();

		  Quaternion_Update(q);

		  BNO080_Roll=-BNO080_Roll;
		  BNO080_Pitch=-BNO080_Pitch;

		  //printf("%.2f\t%.2f\n", BNO080_Roll, BNO080_Pitch);
		  //printf("%.2f\n", BNO080_Yaw);
	  }

	  if(ICM20602_DataReady()==1){
		  LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_1);
		  ICM20602_Get3AxisGyroRawData(&ICM20602.gyro_x_raw);

		  ICM20602.gyro_x=ICM20602.gyro_x_raw*2000.f/32768.f;
		  ICM20602.gyro_y=ICM20602.gyro_y_raw*2000.f/32768.f;
		  ICM20602.gyro_z=ICM20602.gyro_z_raw*2000.f/32768.f;

		  ICM20602.gyro_x=-ICM20602.gyro_x;
		  ICM20602.gyro_z=-ICM20602.gyro_z;

		  //printf("%d  %d  %d\n", ICM20602.gyro_x_raw, ICM20602.gyro_y_raw, ICM20602.gyro_z_raw);
		  //printf("%d  %d  %d\n", (int)(ICM20602.gyro_x*100), (int)(ICM20602.gyro_y*100), (int)(ICM20602.gyro_z*100));
	  }

	  if(LPS22HH_DataReady()==1){
		  LPS22HH_GetPressure(&LPS22HH.pressure_raw);
		  LPS22HH_GetTemperature(&LPS22HH.temperature_raw);

		  LPS22HH.baroAlt=getAltitude2(LPS22HH.pressure_raw/4096.f, LPS22HH.temperature_raw/100.f);

#define X 0.90f
		  LPS22HH.baroAltFilt=LPS22HH.baroAltFilt*X+LPS22HH.baroAlt*(1.0f-X);		// well-known digital filter expression

		  //printf("%d %d\n", (int)(LPS22HH.baroAlt*100), (int)(LPS22HH.baroAltFilt*100));		// (X)cm
	  }

	  if(m8n_rx_cplt_flag==1){
		  m8n_rx_cplt_flag=0;

		  if(M8N_UBX_CHKSUM_Check(m8n_rx_buf, 36)==1){
			  LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_2);
			  M8N_UBX_POSLLH_Parsing(m8n_rx_buf, &polish);

			  //printf("LAT: %ld\tLON: %ld\tHeight: %ld\n", polish.lat, polish.lon, polish.height);
		  }
	  }

	  if(ibus_rx_cplt_flag==1){		// iA6B controller
		  ibus_rx_cplt_flag=0;
		  if(iBus_Check_CHKSUM(ibus_rx_buf, 32)==1){
			  LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_2);

			  iBus_Parsing(ibus_rx_buf, &iBus);
			  iBus_rx_cnt++;
			  if(iBus_IsActiveFailsafe(&iBus)==1){
				  failsafe_flag=1;
			  }else{
				  failsafe_flag=0;
			  }
			  //			  printf("%d\t%d\t%d\t%d\t%d\t%d\n",
			  //					  iBus.RH, iBus.RV, iBus.LV, iBus.LH, iBus.SwA, iBus.SwC);
			  //			  HAL_Delay(100);
		  }
	  }

	  if(tim7_1000ms_flag==1){
		  tim7_1000ms_flag=0;
		  if(iBus_rx_cnt==0){
			  failsafe_flag=2;
		  }
		  iBus_rx_cnt=0;
	  }

	  if(failsafe_flag==1 || failsafe_flag==2 || low_bat_flag==1 || iBus.SwC==2000){
		  LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	  }else{
		  LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	  }

  }



  int sumCount=0;
  int sumLPS22HH=0;
  int baseAvgLPS22HH;
AutoMode:

start_flag=1;
  while(start_cnt<3){				//  3초간 기압고도계의 데이터를 얻어와 데이터가 안정화 되기를 기다림, 바로 처음부터 평균값을 구하면 이상해짐
  	if(LPS22HH_DataReady()==1){
  			LPS22HH_GetPressure(&LPS22HH.pressure_raw);
  			LPS22HH_GetTemperature(&LPS22HH.temperature_raw);

  			LPS22HH.baroAlt=getAltitude2(LPS22HH.pressure_raw/4096.f, LPS22HH.temperature_raw/100.f);

  	#define X 0.90f
  			LPS22HH.baroAltFilt=LPS22HH.baroAltFilt*X+LPS22HH.baroAlt*(1.0f-X);		// well-known digital filter expression

  			//printf("%d %d\n", (int)(LPS22HH.baroAlt*100), (int)(LPS22HH.baroAltFilt*100));		// (X)cm

//  			printf("%d\n", (int)(LPS22HH.baroAltFilt*100));
//  			sumCount++;
//  			sumLPS22HH+=LPS22HH.baroAltFilt*100;
  	}
  }
  start_flag=0;
  start_cnt=0;

  start_flag=1;
  while(start_cnt<3){				//  안정화됨 데이터를 3초간 얻어와 평균
    	if(LPS22HH_DataReady()==1){
    			LPS22HH_GetPressure(&LPS22HH.pressure_raw);
    			LPS22HH_GetTemperature(&LPS22HH.temperature_raw);

    			LPS22HH.baroAlt=getAltitude2(LPS22HH.pressure_raw/4096.f, LPS22HH.temperature_raw/100.f);

    	#define X 0.90f
    			LPS22HH.baroAltFilt=LPS22HH.baroAltFilt*X+LPS22HH.baroAlt*(1.0f-X);		// well-known digital filter expression

    			//printf("%d %d\n", (int)(LPS22HH.baroAlt*100), (int)(LPS22HH.baroAltFilt*100));		// (X)cm

    			sumCount++;
    			sumLPS22HH+=LPS22HH.baroAltFilt*100;
    	}
    }

  baseAvgLPS22HH=sumLPS22HH/sumCount;
  start_flag=0;
  start_cnt=0;

// 1. Need Takeoff code :  while문 밖에서 자동비행전에 지정된 고도로 먼저 올라가야 함
while(!((LPS22HH.baroAltFilt*100-baseAvgLPS22HH)<destGPS.height+15 && (LPS22HH.baroAltFilt*100-baseAvgLPS22HH)>destGPS.height-15)){
	Double_Roll_Pitch_PID_Calculation(&pitch, (0)*0.1f, BNO080_Pitch, ICM20602.gyro_x);
	Double_Roll_Pitch_PID_Calculation(&roll, (0)*0.1f, BNO080_Roll, ICM20602.gyro_y);
	Double_Height_Calculation(destGPS.height, (LPS22HH.baroAltFilt*100-baseAvgLPS22HH), &height);

	ccr1=10500+500+ height.in.pid_result - pitch.in.pid_result + roll.in.pid_result;
	ccr2=10500+500+ height.in.pid_result + pitch.in.pid_result + roll.in.pid_result;
	ccr3=10500+500+ height.in.pid_result + pitch.in.pid_result - roll.in.pid_result;
	ccr4=10500+500+ height.in.pid_result - pitch.in.pid_result - roll.in.pid_result;

	TIM5->CCR1=(ccr1>21000)?21000:(ccr1<11000)?11000:ccr1;
	TIM5->CCR2=(ccr2>21000)?21000:(ccr2<11000)?11000:ccr2;
	TIM5->CCR3=(ccr3>21000)?21000:(ccr3<11000)?11000:ccr3;
	TIM5->CCR4=(ccr4>21000)?21000:(ccr4<11000)?11000:ccr4;

	if(telemetry_rx_cplt_flag==1){
		telemetry_rx_cplt_flag=0;

		if(arrive_flag==0){
			unsigned char chksum=0xff;

			for(int i=0; i<19; i++) chksum-=telemetry_rx_buf[i];

			if(chksum==telemetry_rx_buf[19]){
				switch(telemetry_rx_buf[2]){
				case 0x11:
					receiveGPS_Parsing(telemetry_rx_buf);
					break;
				}
			}
		}
	}

	if(tim7_20ms_flag==1 && tim7_100ms_flag!=1){
		tim7_20ms_flag=0;

		Encode_Msg_AHRS(telemetry_tx_buf);

		HAL_UART_Transmit_IT(&huart1, telemetry_tx_buf, 20);
	}else if(tim7_100ms_flag==1 && tim7_20ms_flag==1){
		tim7_20ms_flag=0;
		tim7_100ms_flag=0;

		Encode_Msg_AHRS(telemetry_tx_buf);
		Encode_Msg_GPS(telemetry_tx_buf+20);

		HAL_UART_Transmit_IT(&huart1, telemetry_tx_buf, 40);
	}

	batVolt=adcVal*0.003619f;
	//	  printf("%d\t%.2f\n", adcVal, batVolt);
	if(batVolt<10.0f){
		low_bat_flag=1;
	}else{
		low_bat_flag=0;
	}

	if(BNO080_dataAvailable()==1){
		LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_0);

		q[0]=BNO080_getQuatI();
		q[1]=BNO080_getQuatJ();
		q[2]=BNO080_getQuatK();
		q[3]=BNO080_getQuatReal();
		quatRadianAccuracy=BNO080_getQuatRadianAccuracy();

		Quaternion_Update(q);

		BNO080_Roll=(-BNO080_Roll);
		BNO080_Pitch=(-BNO080_Pitch);

		//printf("%.2f\t%.2f\n", BNO080_Roll, BNO080_Pitch);
		//printf("%.2f\n", BNO080_Yaw);
	}

	if(ICM20602_DataReady()==1){
		LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_1);
		ICM20602_Get3AxisGyroRawData(&ICM20602.gyro_x_raw);

		ICM20602.gyro_x=ICM20602.gyro_x_raw*2000.f/32768.f;
		ICM20602.gyro_y=ICM20602.gyro_y_raw*2000.f/32768.f;
		ICM20602.gyro_z=ICM20602.gyro_z_raw*2000.f/32768.f;

		ICM20602.gyro_x=(-ICM20602.gyro_x);
		ICM20602.gyro_z=(-ICM20602.gyro_z);

		//printf("%d  %d  %d\n", ICM20602.gyro_x_raw, ICM20602.gyro_y_raw, ICM20602.gyro_z_raw);
		//printf("%d  %d  %d\n", (int)(ICM20602.gyro_x*100), (int)(ICM20602.gyro_y*100), (int)(ICM20602.gyro_z*100));
	}

	if(LPS22HH_DataReady()==1){
		LPS22HH_GetPressure(&LPS22HH.pressure_raw);
		LPS22HH_GetTemperature(&LPS22HH.temperature_raw);

		LPS22HH.baroAlt=getAltitude2(LPS22HH.pressure_raw/4096.f, LPS22HH.temperature_raw/100.f);

#define X 0.90f
		LPS22HH.baroAltFilt=LPS22HH.baroAltFilt*X+LPS22HH.baroAlt*(1.0f-X);		// well-known digital filter expression

		//printf("%d %d\n", (int)(LPS22HH.baroAlt*100), (int)(LPS22HH.baroAltFilt*100));		// (X)cm
	}

	if(m8n_rx_cplt_flag==1){
		m8n_rx_cplt_flag=0;

		if(M8N_UBX_CHKSUM_Check(m8n_rx_buf, 36)==1){
			LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_2);
			M8N_UBX_POSLLH_Parsing(m8n_rx_buf, &polish);

			//printf("LAT: %ld\tLON: %ld\tHeight: %ld\n", polish.lat, polish.lon, polish.height);
		}
	}


	if(tim7_1000ms_flag==1){
		tim7_1000ms_flag=0;
		if(iBus_rx_cnt==0){
			failsafe_flag=2;
		}
		iBus_rx_cnt=0;
	}

	if(failsafe_flag==1 || failsafe_flag==2 || low_bat_flag==1 || iBus.SwC==2000){
		LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	}else{
		LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	}
}

while (1)
  {
	  if(tim7_1ms_flag==1){
		  tim7_1ms_flag=0;

		  if(autopilot_flag==1){
			  Is_Arrived();

			  if(arrive_flag==0){
				  target_angle=calcAngleGPS((float)destGPS.lon_f63, (float)destGPS.lat_f63);

				  Double_Roll_Pitch_PID_Calculation(&pitch, (100)*0.1f, BNO080_Pitch, ICM20602.gyro_x);		// 100 is temporary value
				  Double_Roll_Pitch_PID_Calculation(&roll, (0)*0.1f, BNO080_Roll, ICM20602.gyro_y);
				  Single_Yaw_Heading_PID_Calculation(&yaw_heading, target_angle, BNO080_Yaw, ICM20602.gyro_z);
				  Double_Height_Calculation(destGPS.height, (LPS22HH.baroAltFilt-baseAvgLPS22HH)*100, &height);

				  //Double_Height_Calculation(destGPS.height, (LPS22HH.baroAltFilt*100>destGPS.height+15 || LPS22HH.baroAltFilt*100<destGPS.height-15)?LPS22HH.baroAltFilt*100:destGPS.height, &height);
				  //	: taget 입력값은 목표 LPS22HH의 고도 단위, 구해진 pid값을 일정 범위로 제한할 필요가 있음, 0~10000 사이, 그러나 10000은 너무 크니 절반으로 제하하여야 할듯, pid 구할때 게인을 얼마큼 주냐에 따라 높이 상승하는 속도가 달라짐
				  //	고도 PID의 경우 비교대상이 	범위가 너무 크다 보니 범위를 축소하기 보다는 범위에 따른 pid 결과를 축소시킬 필요가 있어 보임, 아니면 입력 고도에 대한 최대 제한이 필요해 보임,
				  //	롤,피치의 경우 범위가 180내외로 센서값이 도출되고 입력값도 -50~50도로 제한하여 비교하고 있음

				  ccr1=10500+500+ height.in.pid_result - pitch.in.pid_result + roll.in.pid_result - yaw_heading.pid_result;
				  ccr2=10500+500+ height.in.pid_result + pitch.in.pid_result + roll.in.pid_result + yaw_heading.pid_result;
				  ccr3=10500+500+ height.in.pid_result + pitch.in.pid_result - roll.in.pid_result - yaw_heading.pid_result;
				  ccr4=10500+500+ height.in.pid_result - pitch.in.pid_result - roll.in.pid_result + yaw_heading.pid_result;
			  }else{
				  Double_Roll_Pitch_PID_Calculation(&pitch, (0)*0.1f, BNO080_Pitch, ICM20602.gyro_x);		// 0 is holding
				  Double_Roll_Pitch_PID_Calculation(&roll, (0)*0.1f, BNO080_Roll, ICM20602.gyro_y);
				  Single_Yaw_Heading_PID_Calculation(&yaw_heading, target_angle, BNO080_Yaw, ICM20602.gyro_z);
				  Double_Height_Calculation(destGPS.height, LPS22HH.baroAltFilt*100, &height);

				  ccr1=10500+500+ height.in.pid_result - pitch.in.pid_result + roll.in.pid_result - yaw_heading.pid_result;
				  ccr2=10500+500+ height.in.pid_result + pitch.in.pid_result + roll.in.pid_result + yaw_heading.pid_result;
				  ccr3=10500+500+ height.in.pid_result + pitch.in.pid_result - roll.in.pid_result - yaw_heading.pid_result;
				  ccr4=10500+500+ height.in.pid_result - pitch.in.pid_result - roll.in.pid_result + yaw_heading.pid_result;
			  }
		  }

		  if(arrive_flag==1){			// or land_flag
			  Reset_All_PID_Integrator();
		  }
	  }


	  TIM5->CCR1=(ccr1>21000)?21000:(ccr1<11000)?11000:ccr1;
	  TIM5->CCR2=(ccr2>21000)?21000:(ccr2<11000)?11000:ccr2;
	  TIM5->CCR3=(ccr3>21000)?21000:(ccr3<11000)?11000:ccr3;
	  TIM5->CCR4=(ccr4>21000)?21000:(ccr4<11000)?11000:ccr4;


	  if(telemetry_rx_cplt_flag==1){
		  telemetry_rx_cplt_flag=0;

		  if(arrive_flag==0){
			  unsigned char chksum=0xff;

			  for(int i=0; i<19; i++) chksum-=telemetry_rx_buf[i];

			  if(chksum==telemetry_rx_buf[19]){
				  switch(telemetry_rx_buf[2]){
				  case 0x11:
					  receiveGPS_Parsing(telemetry_rx_buf);
					  break;
				  }
			  }
		  }
	  }

	  if(destGPS.gcs_failsafe==1){
		  /*
		   * break해서 while문을 아에 빠져나가던지
		   * 이곳에 무한루프로 가두어서 모터를 0으로 만들던지
		   */
	  }

	  if(tim7_20ms_flag==1 && tim7_100ms_flag!=1){
		  tim7_20ms_flag=0;

		  Encode_Msg_AHRS(telemetry_tx_buf);

		  HAL_UART_Transmit_IT(&huart1, telemetry_tx_buf, 20);
	  }else if(tim7_100ms_flag==1 && tim7_20ms_flag==1){
		  tim7_20ms_flag=0;
		  tim7_100ms_flag=0;

		  Encode_Msg_AHRS(telemetry_tx_buf);
		  Encode_Msg_GPS(telemetry_tx_buf+20);

		  HAL_UART_Transmit_IT(&huart1, telemetry_tx_buf, 40);
	  }

	  batVolt=adcVal*0.003619f;
//	  printf("%d\t%.2f\n", adcVal, batVolt);
	  if(batVolt<10.0f){
		  low_bat_flag=1;
	  }else{
		  low_bat_flag=0;
	  }

	  if(BNO080_dataAvailable()==1){
		  LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_0);

		  q[0]=BNO080_getQuatI();
		  q[1]=BNO080_getQuatJ();
		  q[2]=BNO080_getQuatK();
		  q[3]=BNO080_getQuatReal();
		  quatRadianAccuracy=BNO080_getQuatRadianAccuracy();

		  Quaternion_Update(q);

		  BNO080_Roll=(-BNO080_Roll);
		  BNO080_Pitch=(-BNO080_Pitch);

		  //printf("%.2f\t%.2f\n", BNO080_Roll, BNO080_Pitch);
		  //printf("%.2f\n", BNO080_Yaw);
	  }

	  if(ICM20602_DataReady()==1){
		  LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_1);
		  ICM20602_Get3AxisGyroRawData(&ICM20602.gyro_x_raw);

		  ICM20602.gyro_x=ICM20602.gyro_x_raw*2000.f/32768.f;
		  ICM20602.gyro_y=ICM20602.gyro_y_raw*2000.f/32768.f;
		  ICM20602.gyro_z=ICM20602.gyro_z_raw*2000.f/32768.f;

		  ICM20602.gyro_x=(-ICM20602.gyro_x);
		  ICM20602.gyro_z=(-ICM20602.gyro_z);

		  //printf("%d  %d  %d\n", ICM20602.gyro_x_raw, ICM20602.gyro_y_raw, ICM20602.gyro_z_raw);
		  //printf("%d  %d  %d\n", (int)(ICM20602.gyro_x*100), (int)(ICM20602.gyro_y*100), (int)(ICM20602.gyro_z*100));
	  }

	  if(LPS22HH_DataReady()==1){
		  LPS22HH_GetPressure(&LPS22HH.pressure_raw);
		  LPS22HH_GetTemperature(&LPS22HH.temperature_raw);

		  LPS22HH.baroAlt=getAltitude2(LPS22HH.pressure_raw/4096.f, LPS22HH.temperature_raw/100.f);

#define X 0.90f
		  LPS22HH.baroAltFilt=LPS22HH.baroAltFilt*X+LPS22HH.baroAlt*(1.0f-X);		// well-known digital filter expression

		  //printf("%d %d\n", (int)(LPS22HH.baroAlt*100), (int)(LPS22HH.baroAltFilt*100));		// (X)cm
	  }

	  if(m8n_rx_cplt_flag==1){
		  m8n_rx_cplt_flag=0;

		  if(M8N_UBX_CHKSUM_Check(m8n_rx_buf, 36)==1){
			  LL_GPIO_TogglePin(GPIOC, LL_GPIO_PIN_2);
			  M8N_UBX_POSLLH_Parsing(m8n_rx_buf, &polish);

			  //printf("LAT: %ld\tLON: %ld\tHeight: %ld\n", polish.lat, polish.lon, polish.height);
		  }
	  }


	  if(tim7_1000ms_flag==1){
		  tim7_1000ms_flag=0;
		  if(iBus_rx_cnt==0){
			  failsafe_flag=2;
		  }
		  iBus_rx_cnt=0;
	  }

	  if(failsafe_flag==1 || failsafe_flag==2 || low_bat_flag==1 || iBus.SwC==2000){
		  LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	  }else{
		  LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	  }

	  // if(landing_flag==1) break;
  }

	// 2. Need Landing code : 목적지에 도착하면  while문을 나와 착륙 동작을 다로 수행하여야 함
	// 		Do landing
	//		if end flight : return, or continue flight : goto AutoMode

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage 
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
int Is_iBus_Throttle_Min(void){
	if(ibus_rx_cplt_flag==1){		// iA6B controller
		ibus_rx_cplt_flag=0;

		if(iBus_Check_CHKSUM(ibus_rx_buf, 32)==1){
			iBus_Parsing(ibus_rx_buf, &iBus);
			if(iBus.LV<1010) return 1;
		}
	}

	return 0;
}

void ESC_Calibration(void){
	//ESC Calibration, MAX Pulse width 7seconds wait, MIN Pulse width 8seconds wait
	TIM5->CCR1=21000;
	TIM5->CCR2=21000;
	TIM5->CCR3=21000;
	TIM5->CCR4=21000;
	HAL_Delay(7000);
	TIM5->CCR1=10500;
	TIM5->CCR2=10500;
	TIM5->CCR3=10500;
	TIM5->CCR4=10500;
	HAL_Delay(8000);
}

int Is_iBus_Received(void){
	if(ibus_rx_cplt_flag==1){		// iA6B controller
		ibus_rx_cplt_flag=0;

		if(iBus_Check_CHKSUM(ibus_rx_buf, 32)==1){
			iBus_Parsing(ibus_rx_buf, &iBus);
			return 1;
		}
	}

	return 0;
}

void BNO080_Calibration(unsigned char autopilot_flag)
{
	//Resets BNO080 to disable All output
	BNO080_Initialization();

	//BNO080/BNO085 Configuration
	//Enable dynamic calibration for accelerometer, gyroscope, and magnetometer
	//Enable Game Rotation Vector output
	//Enable Magnetic Field output
	BNO080_calibrateAll(); //Turn on cal for Accel, Gyro, and Mag
	BNO080_enableGameRotationVector(20000); //Send data update every 20ms (50Hz)
	BNO080_enableMagnetometer(20000); //Send data update every 20ms (50Hz)

	//Once magnetic field is 2 or 3, run the Save DCD Now command
  	printf("Calibrating BNO080. Pull up FS-i6 SWC to end calibration and save to flash\n");
  	printf("Output in form x, y, z, in uTesla\n\n");

	//while loop for calibration procedure
	//Iterates until iBus.SwC is mid point (1500)
	//Calibration procedure should be done while this loop is in iteration.
	while(iBus.SwC == 1500)
	{
		if(BNO080_dataAvailable() == 1)
		{
			//Observing the status bit of the magnetic field output
			float x = BNO080_getMagX();
			float y = BNO080_getMagY();
			float z = BNO080_getMagZ();
			unsigned char accuracy = BNO080_getMagAccuracy();

			float quatI = BNO080_getQuatI();
			float quatJ = BNO080_getQuatJ();
			float quatK = BNO080_getQuatK();
			float quatReal = BNO080_getQuatReal();
			unsigned char sensorAccuracy = BNO080_getQuatAccuracy();

			printf("%f,%f,%f,", x, y, z);
			if (accuracy == 0) printf("Unreliable\t");
			else if (accuracy == 1) printf("Low\t");
			else if (accuracy == 2) printf("Medium\t");
			else if (accuracy == 3) printf("High\t");

			printf("\t%f,%f,%f,%f,", quatI, quatI, quatI, quatReal);
			if (sensorAccuracy == 0) printf("Unreliable\n");
			else if (sensorAccuracy == 1) printf("Low\n");
			else if (sensorAccuracy == 2) printf("Medium\n");
			else if (sensorAccuracy == 3) printf("High\n");

			//Turn the LED and buzzer on when both accuracy and sensorAccuracy is high
			if(accuracy == 3 && sensorAccuracy == 3)
			{
				LL_GPIO_SetOutputPin(GPIOC, LL_GPIO_PIN_0 | LL_GPIO_PIN_1 | LL_GPIO_PIN_2);
				TIM3->PSC = 65000; //Very low frequency
				LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
			}
			else
			{
				LL_GPIO_ResetOutputPin(GPIOC, LL_GPIO_PIN_0 | LL_GPIO_PIN_1 | LL_GPIO_PIN_2);
				LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
			}
		}

		Is_iBus_Received(); //Refreshes iBus Data for iBus.SwC
		HAL_Delay(100);
	}

	//Ends the loop when iBus.SwC is not mid point
	//Turn the LED and buzzer off
	LL_GPIO_ResetOutputPin(GPIOC, LL_GPIO_PIN_0 | LL_GPIO_PIN_1 | LL_GPIO_PIN_2);
	LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);

	//Saves the current dynamic calibration data (DCD) to memory
	//Sends command to get the latest calibration status
	BNO080_saveCalibration();
	BNO080_requestCalibrationStatus();

	//Wait for calibration response, timeout if no response
	int counter = 100;
	while(1)
	{
		if(--counter == 0) break;
		if(BNO080_dataAvailable())
		{
			//The IMU can report many different things. We must wait
			//for the ME Calibration Response Status byte to go to zero
			if(BNO080_calibrationComplete() == 1)
			{
				printf("\nCalibration data successfully stored\n");
				LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
				TIM3->PSC = 2000;
				HAL_Delay(300);
				TIM3->PSC = 1500;
				HAL_Delay(300);
				LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
				HAL_Delay(1000);
				break;
			}
		}
		HAL_Delay(10);
	}
	if(counter == 0)
	{
		printf("\nCalibration data failed to store. Please try again.\n");
		LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
		TIM3->PSC = 1500;
		HAL_Delay(300);
		TIM3->PSC = 2000;
		HAL_Delay(300);
		LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
		HAL_Delay(1000);
	}

	//BNO080_endCalibration(); //Turns off all calibration
	//In general, calibration should be left on at all times. The BNO080
	//auto-calibrates and auto-records cal data roughly every 5 minutes

	//Resets BNO080 to disable Game Rotation Vector and Magnetometer
	//Enables Rotation Vector
	BNO080_Initialization();

	if(autopilot_flag==1) BNO080_enableRotationVector(2500);
	else BNO080_enableGameRotationVector(2500);
	//BNO080_enableRotationVector(2500); //Send data update every 2.5ms (400Hz)
	//BNO080_enableGameRotationVector(2500);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){		// Interrupt Callback Function Override
	static unsigned char cnt=0;

	if(huart->Instance==USART1){
		HAL_UART_Receive_IT(&huart1, &uart1_rx_data, 1);		// 1byte receive ready

		switch(cnt){
			case 0:
				if(uart1_rx_data==0x47){
					telemetry_rx_buf[cnt]=uart1_rx_data;
					cnt++;
				}
				break;
			case 1:
				if(uart1_rx_data==0x53){
					telemetry_rx_buf[cnt]=uart1_rx_data;
					cnt++;
				}else{
					cnt=0;
				}
				break;
			case 19:
				telemetry_rx_buf[cnt]=uart1_rx_data;
				cnt=0;
				telemetry_rx_cplt_flag=1;
				break;
			default:
				telemetry_rx_buf[cnt]=uart1_rx_data;
				cnt++;
				break;
		}
	}
}

void Encode_Msg_AHRS(unsigned char *telemetry_tx_buf){
	telemetry_tx_buf[0]=0x46;		// 'F'
	telemetry_tx_buf[1]=0x43;		// 'C'
	telemetry_tx_buf[2]=0x10;		// id value

	telemetry_tx_buf[3]=(short)(BNO080_Roll*100);
	telemetry_tx_buf[4]=((short)(BNO080_Roll*100))>>8;

	telemetry_tx_buf[5]=(short)(BNO080_Pitch*100);
	telemetry_tx_buf[6]=((short)(BNO080_Pitch*100))>>8;

//	telemetry_tx_buf[5]=(short)(ICM20602.gyro_x*100);
//	telemetry_tx_buf[6]=((short)(ICM20602.gyro_x*100))>>8;

	telemetry_tx_buf[7]=(unsigned short)(BNO080_Yaw*100);
	telemetry_tx_buf[8]=((unsigned short)(BNO080_Yaw*100))>>8;

	telemetry_tx_buf[9]=(short)(LPS22HH.baroAltFilt*10);
	telemetry_tx_buf[10]=((short)(LPS22HH.baroAltFilt*10))>>8;

	telemetry_tx_buf[11]=(short)((iBus.RH-1500)*0.1f*100);
	telemetry_tx_buf[12]=((short)((iBus.RH-1500)*0.1f*100))>>8;

	telemetry_tx_buf[13]=(short)((iBus.RV-1500)*0.1f*100);
	telemetry_tx_buf[14]=((short)((iBus.RV-1500)*0.1f*100))>>8;

	telemetry_tx_buf[15]=(unsigned short)((iBus.LH-1000)*0.36f*100);
	telemetry_tx_buf[16]=((unsigned short)((iBus.LH-1000)*0.36f*100))>>8;

	telemetry_tx_buf[17]=(short)(iBus.LV*10);
	telemetry_tx_buf[18]=((short)(iBus.LV*10))>>8;

	telemetry_tx_buf[19]=0xff; 		// chksum

	for(int i=0; i<19; i++) telemetry_tx_buf[19] -= telemetry_tx_buf[i];
}

void Encode_Msg_GPS(unsigned char *telemetry_tx_buf){
	telemetry_tx_buf[0]=0x46;
	telemetry_tx_buf[1]=0x43;
	telemetry_tx_buf[2]=0x11;

	telemetry_tx_buf[3]=polish.lat;		// 4byte
	telemetry_tx_buf[4]=polish.lat>>8;
	telemetry_tx_buf[5]=polish.lat>>16;
	telemetry_tx_buf[6]=polish.lat>>24;

	telemetry_tx_buf[7]=polish.lon;		// 4byte
	telemetry_tx_buf[8]=polish.lon>>8;
	telemetry_tx_buf[9]=polish.lon>>16;
	telemetry_tx_buf[10]=polish.lon>>24;

	telemetry_tx_buf[11]=(unsigned short)(batVolt*100);
	telemetry_tx_buf[12]=((unsigned short)(batVolt*100))>>8;

	telemetry_tx_buf[13]=(iBus.SwA==1000)?0:1;
	telemetry_tx_buf[14]=(iBus.SwC==1000)?0:(iBus.SwC==1500)?1:2;
	telemetry_tx_buf[15]=failsafe_flag;

	telemetry_tx_buf[16]=0x00;
	telemetry_tx_buf[17]=0x00;
	telemetry_tx_buf[18]=0x00;

	telemetry_tx_buf[19]=0xff; 		// chksum

	for(int i=0; i<19; i++) telemetry_tx_buf[19] -= telemetry_tx_buf[i];
}

void Encode_Msg_PID_Gain(unsigned char *telemetry_tx_buf, unsigned char id, float p, float i, float d){
	telemetry_tx_buf[0]=0x46;
	telemetry_tx_buf[1]=0x43;
	telemetry_tx_buf[2]=id;

//	memcpy(telemetry_tx_buf+3, &p, 4);
//	memcpy(telemetry_tx_buf+7, &i, 4);
//	memcpy(telemetry_tx_buf+11, &d, 4);

	(*(float*)(telemetry_tx_buf+3))=p;
	(*(float*)(telemetry_tx_buf+7))=i;
	(*(float*)(telemetry_tx_buf+11))=d;

	telemetry_tx_buf[15]=0x00;
	telemetry_tx_buf[16]=0x00;
	telemetry_tx_buf[17]=0x00;
	telemetry_tx_buf[18]=0x00;

	telemetry_tx_buf[19]=0xff; 		// chksum

	for(int i=0; i<19; i++) telemetry_tx_buf[19] -= telemetry_tx_buf[i];
}

void receiveGPS_Parsing(unsigned char *telemetry_rx_buf){
	destGPS.lat=*((int*)(telemetry_rx_buf+3));		// y, 위도
	destGPS.lon=*((int*)(telemetry_rx_buf+7));		// x, 경도
	destGPS.lat_f63=destGPS.lat/10000000.f;
	destGPS.lon_f63=destGPS.lon/10000000.f;

	destGPS.gcs_failsafe=*((unsigned char*)(telemetry_rx_buf+16));		// 비상모드
	destGPS.height=*((unsigned short*)(telemetry_rx_buf+17));		// z, 고도
}

float calcAngleGPS(float target_x, float target_y){
	float angle=atan2f(target_x-polish.lon_f63, target_y-polish.lat_f63)*180/(float)PI;

	if(angle<0){
		angle=(180-angle)+180;
	}

	angle=angle-BNO080_Yaw;

	return angle;
}

#define error_range 0.000020
void Is_Arrived(void){
	if ((polish.lat < destGPS.lat + error_range && polish.lat > destGPS.lat - error_range ) &&		// Only lat have (+)value, Global -> lat : -90~90, lon : -180~180
			(polish.lon < destGPS.lon + error_range && polish.lon > destGPS.lon - error_range )){
		arrive_flag=1;
	}else{
		arrive_flag=0;
	}
}

void ModeSelectAlram(void){
	TIM3->PSC=1500;

	LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(300);
	LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(200);

	LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(300);
	LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(200);

	LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(300);
	LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(200);
}
void AutopilotModeAlram(void){
	TIM3->PSC=3000;

	LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(300);
	LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(200);

	LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(300);
	LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(200);

	LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(300);
	LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(200);
}
void ManualpilotModeAlram(void){
	TIM3->PSC=1000;

	LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(300);
	LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(200);

	LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(300);
	LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(200);

	LL_TIM_CC_EnableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(300);
	LL_TIM_CC_DisableChannel(TIM3, LL_TIM_CHANNEL_CH4);
	HAL_Delay(200);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
